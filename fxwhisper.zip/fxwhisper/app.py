import json
import sys
from datetime import date

from fx_trade_parser import parse_trade


def _read_input() -> str:
    if len(sys.argv) > 1:
        return " ".join(sys.argv[1:]).strip()
    return sys.stdin.read().strip()


def main() -> int:
    text = _read_input()
    if not text:
        print("Provide a trade instruction as arguments or via stdin.", file=sys.stderr)
        return 1

    result = parse_trade(text, reference_date=date.today())
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
