"use client";

import { useEffect, useState } from "react";

type ParseResult = {
  client: string | null;
  currency_pair: string | null;
  side: string | null;
  size: number | null;
  value_date: string | null;
  confidence: string | null;
};

type ProcessResponse = {
  result: ParseResult;
  record_id: string;
};

const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://127.0.0.1:8000";

const BASE_RATES: Record<string, number> = {
  "EUR/USD": 1.09,
  "USD/JPY": 146.2,
  "GBP/USD": 1.27,
  "USD/CAD": 1.36,
  "USD/KRW": 1330,
  "EUR/GBP": 0.85,
  "AUD/USD": 0.67,
  "NZD/USD": 0.61,
};

function simulateRate(pair: string | null) {
  const base = pair ? BASE_RATES[pair] : undefined;
  const mid = (base ?? 1.0) * (1 + (Math.random() - 0.5) * 0.0015);
  const spread = mid * 0.0004;
  const bid = mid - spread / 2;
  const ask = mid + spread / 2;
  return { mid, bid, ask };
}

export default function Page() {
  const [status, setStatus] = useState("Idle");
  const [result, setResult] = useState<ParseResult | null>(null);
  const [recordId, setRecordId] = useState<string | null>(null);
  const [records, setRecords] = useState<any[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [rate, setRate] = useState(() => ({ mid: 0, bid: 0, ask: 0 }));
  const [selectedPair, setSelectedPair] = useState<string>("EUR/USD");

  useEffect(() => {
    const pair = selectedPair || result?.currency_pair || null;
    setRate(simulateRate(pair));
    const timer = setInterval(() => {
      setRate(simulateRate(pair));
    }, 1000);
    return () => clearInterval(timer);
  }, [result, selectedPair]);

  const refreshRecords = async () => {
    const response = await fetch(`${API_BASE}/records`);
    const data = await response.json();
    if (response.ok) {
      setRecords(data);
    }
  };

  const handleRecord = async () => {
    setStatus("Recording...");
    setIsRecording(true);
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mimeTypes = [
      "audio/webm;codecs=opus",
      "audio/webm",
      "audio/ogg;codecs=opus",
      "audio/ogg",
    ];
    const mimeType = mimeTypes.find((type) => MediaRecorder.isTypeSupported(type));
    const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
    const chunks: Blob[] = [];
    recorder.ondataavailable = (event) => chunks.push(event.data);
    recorder.onstop = async () => {
      setStatus("Sending audio...");
      if (!chunks.length || chunks.every((chunk) => chunk.size === 0)) {
        setStatus("Error: No audio captured. Check mic permissions.");
        return;
      }
      const blobType = mimeType || "audio/webm";
      const blob = new Blob(chunks, { type: blobType });
      const formData = new FormData();
      const extension = blobType.includes("ogg") ? "ogg" : "webm";
      formData.append("audio", blob, `audio.${extension}`);

      const response = await fetch(`${API_BASE}/process`, {
        method: "POST",
        body: formData,
      });
      const data: ProcessResponse & { detail?: string } = await response.json();
      if (!response.ok) {
        setStatus(`Error: ${data.detail || response.status}`);
        return;
      }

      setResult(data.result);
      setRecordId(data.record_id);
      setStatus("Parsed.");
      await refreshRecords();
    };
    recorder.start();
    setMediaRecorder(recorder);
  };

  const handleStop = () => {
    setStatus("Stopping...");
    setIsRecording(false);
    if (mediaRecorder && mediaRecorder.state !== "inactive") {
      mediaRecorder.stop();
      mediaRecorder.stream.getTracks().forEach((track) => track.stop());
    }
  };

  return (
    <div className="page">
      <div className="split">
        <div className="panel">
          <h3>Voice Capture</h3>
          <div className="rate-grid">
            <button className="cta" onClick={handleRecord} disabled={isRecording}>
              Start recording
            </button>
            <button className="cta secondary" onClick={handleStop} disabled={!isRecording}>
              Stop
            </button>
            <div className="tile">
              <small>Status</small>
              {status}
            </div>
          </div>
          {recordId ? <div className="status">Record: {recordId}</div> : null}
          <div className="status">
            Pair: {result?.currency_pair || "-"} · Side: {result?.side || "-"} · Size:{" "}
            {result?.size ? result.size.toLocaleString() : "-"}
          </div>
        </div>

        <div className="panel">
          <h3>Parsed JSON</h3>
          <div className="result">
            {result ? JSON.stringify(result, null, 2) : "Awaiting trade..."}
          </div>
        </div>
      </div>

      <div className="topbar">
        <div className="field">
          <select defaultValue="NDF">
            <option>NDF</option>
            <option>Spot</option>
            <option>Forward</option>
          </select>
        </div>
        <div className="field">
          <select defaultValue="Two-Way">
            <option>Two-Way</option>
            <option>One-Way</option>
          </select>
        </div>
        <div className="field">
          <select
            value={selectedPair}
            onChange={(event) => setSelectedPair(event.target.value)}
          >
            {Object.keys(BASE_RATES).map((pair) => (
              <option key={pair} value={pair}>
                {pair}
              </option>
            ))}
          </select>
        </div>
        <div className="field">
          <input placeholder="RFS" />
        </div>
        <div className="field">
          <input placeholder="1,000,000" />
        </div>
        <div className="field">
          <input type="date" />
        </div>
      </div>

      <div className="subbar">
        <div className="field">
          <input placeholder="Fixing Source" />
        </div>
        <div className="field">
          <input placeholder="Settle Ccy" />
        </div>
        <div className="field">
          <input placeholder="Fixing Date" />
        </div>
        <div className="field">
          <input placeholder="BO Instruction Comment" />
        </div>
      </div>

      <div className="panel" style={{ marginTop: 12 }}>
        <h3>Rates</h3>
        <div className="rate-grid">
          <div className="tile">
            <small>Spot Mid</small>
            {rate.mid.toFixed(5)}
          </div>
          <div className="tile">
            <small>Bid</small>
            {rate.bid.toFixed(5)}
          </div>
          <div className="tile">
            <small>Ask</small>
            {rate.ask.toFixed(5)}
          </div>
        </div>
      </div>

      <div className="side-bars">
        <button className="cta sell">
          Client Sells {result?.currency_pair?.split("/")[0] || "Base"}
          <div>{rate.bid.toFixed(5)}</div>
        </button>
        <div className="panel">
          <h3>Trade Table</h3>
          <table className="table">
            <thead>
              <tr>
                <th>Label</th>
                <th>Value</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Spot Mid</td>
                <td>{rate.mid.toFixed(5)}</td>
              </tr>
              <tr>
                <td>Spread</td>
                <td>{(rate.ask - rate.bid).toFixed(5)}</td>
              </tr>
              <tr>
                <td>Value Date</td>
                <td>{result?.value_date || "-"}</td>
              </tr>
              <tr>
                <td>Client</td>
                <td>{result?.client || "-"}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <button className="cta buy">
          Client Buys {result?.currency_pair?.split("/")[0] || "Base"}
          <div>{rate.ask.toFixed(5)}</div>
        </button>
      </div>

      <div className="records">
        <h3>Saved Records</h3>
        <button className="cta secondary" onClick={refreshRecords}>
          Refresh
        </button>
        {records.length === 0 ? (
          <div className="status">No records yet.</div>
        ) : (
          records.map((record) => (
            <div className="item" key={record.id}>
              <div>Record: {record.id}</div>
              <div>Pair: {record.result?.currency_pair || "-"}</div>
              <audio controls src={`${API_BASE}/records/${record.id}/audio`} />
            </div>
          ))
        )}
      </div>

      <div className="footer">
        <div>Timeout in 274 secs</div>
        <div>SubAccount: London eNDF</div>
      </div>
    </div>
  );
}
