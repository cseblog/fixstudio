import "./globals.css";

export const metadata = {
  title: "FX Voice Trader",
  description: "Voice-driven FX trade capture and pricing",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
