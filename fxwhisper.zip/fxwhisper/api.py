from datetime import date
from typing import Optional

import base64
import json
import os
import re
import shutil
import subprocess
import tempfile
import uuid
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from openai import OpenAI
from openai import RateLimitError, OpenAIError
from pydantic import BaseModel, Field, field_validator

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
PROMPT_PATH = BASE_DIR / "fx_trade_parser_prompt.txt"
RECORDS_DIR = BASE_DIR / "records"

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

app = FastAPI(title="FX Voice Trade Parser")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ParseRequest(BaseModel):
    text: str = Field(..., description="Raw speech-to-text input")
    reference_date: Optional[date] = Field(
        default=None, description="Reference date for relative value dates"
    )


class ParseResponse(BaseModel):
    client: Optional[str]
    currency_pair: Optional[str]
    side: Optional[str]
    size: Optional[float]
    value_date: Optional[str]
    confidence: Optional[str]
    needs_confirmation: Optional[bool] = None
    confirmation_prompt: Optional[str] = None

    @field_validator("size", mode="before")
    @classmethod
    def _coerce_size(cls, value):
        if value is None:
            return None
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            raw = value.strip().lower().replace(",", "").replace("_", "")
            match = re.match(r"^(\d+(?:\.\d+)?)\s*(million|billion|thousand|m|bn|k)?$", raw)
            if not match:
                raise ValueError("invalid size format")
            number = float(match.group(1))
            magnitude = match.group(2)
            multipliers = {
                None: 1,
                "k": 1_000,
                "thousand": 1_000,
                "m": 1_000_000,
                "million": 1_000_000,
                "bn": 1_000_000_000,
                "billion": 1_000_000_000,
            }
            return number * multipliers[magnitude]
        raise ValueError("invalid size type")


class ProcessResponse(BaseModel):
    result: ParseResponse
    record_id: str


def _load_prompt() -> str:
    return PROMPT_PATH.read_text(encoding="utf-8")


def _ensure_records_dir() -> None:
    RECORDS_DIR.mkdir(parents=True, exist_ok=True)


def _ensure_api_key() -> None:
    if not os.getenv("OPENAI_API_KEY"):
        raise HTTPException(status_code=500, detail="OPENAI_API_KEY is not set.")


def _strip_code_fences(content: str) -> str:
    cleaned = content.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```[a-zA-Z]*\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    return cleaned.strip()


def _extract_json_object(content: str) -> str:
    start = content.find("{")
    end = content.rfind("}")
    if start != -1 and end != -1 and end > start:
        return content[start : end + 1]
    return content


def _normalize_json_numbers(content: str) -> str:
    # Remove underscore separators from numeric literals (e.g. 30_000_000).
    def _strip_underscores(match: re.Match) -> str:
        return match.group(0).replace("_", "")

    return re.sub(r"\b\d[\d_]*\b", _strip_underscores, content)


def _parse_json_or_502(content: str) -> dict:
    cleaned = _strip_code_fences(content)
    cleaned = _extract_json_object(cleaned)
    cleaned = _normalize_json_numbers(cleaned)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise HTTPException(
            status_code=502,
            detail=f"OpenAI returned non-JSON output: {content[:200]}",
        ) from exc


def _openai_parse(text: str) -> ParseResponse:
    _ensure_api_key()
    prompt = _load_prompt()
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": prompt},
                {"role": "user", "content": text},
            ],
            response_format={"type": "json_object"},
            temperature=0,
        )
        content = (response.choices[0].message.content or "").strip()
    except RateLimitError as exc:
        raise HTTPException(
            status_code=402,
            detail="OpenAI quota exceeded. Check billing and limits.",
        ) from exc
    except OpenAIError as exc:
        raise HTTPException(
            status_code=502,
            detail=f"OpenAI request failed: {exc}",
        ) from exc
    data = _parse_json_or_502(content)
    return ParseResponse(**data)


def _audio_format(filename: str) -> str:
    return Path(filename).suffix.lower().lstrip(".") or "wav"


def _ensure_ffmpeg() -> None:
    if not shutil.which("ffmpeg"):
        raise HTTPException(
            status_code=400,
            detail="ffmpeg is required to convert audio. Install with: brew install ffmpeg",
        )


def _coerce_audio(audio_bytes: bytes, filename: str) -> tuple[bytes, str]:
    ext = _audio_format(filename)
    if ext in {"wav", "mp3"}:
        return audio_bytes, ext

    _ensure_ffmpeg()
    with tempfile.NamedTemporaryFile(suffix=f".{ext}") as src, tempfile.NamedTemporaryFile(
        suffix=".wav"
    ) as dst:
        src.write(audio_bytes)
        src.flush()
        cmd = [
            "ffmpeg",
            "-y",
            "-i",
            src.name,
            "-ac",
            "1",
            "-ar",
            "16000",
            dst.name,
        ]
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        dst.flush()
        return dst.read(), "wav"


def _save_record(
    audio_bytes: bytes,
    audio_format: str,
    result: ParseResponse,
) -> str:
    _ensure_records_dir()
    record_id = datetime.utcnow().strftime("%Y%m%d%H%M%S") + "-" + uuid.uuid4().hex[:8]
    record_dir = RECORDS_DIR / record_id
    record_dir.mkdir(parents=True, exist_ok=True)
    audio_path = record_dir / f"audio.{audio_format}"
    result_path = record_dir / "result.json"
    audio_path.write_bytes(audio_bytes)
    result_path.write_text(json.dumps(result.dict(), indent=2), encoding="utf-8")
    return record_id


def _openai_parse_audio(audio_bytes: bytes, filename: str) -> ParseResponse:
    _ensure_api_key()
    prompt = _load_prompt()
    coerced_bytes, audio_format = _coerce_audio(audio_bytes, filename)
    audio_b64 = base64.b64encode(coerced_bytes).decode("ascii")
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini-audio-preview",
            messages=[
                {"role": "system", "content": prompt},
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_audio",
                            "input_audio": {
                                "data": audio_b64,
                                "format": audio_format,
                            },
                        }
                    ],
                },
            ],
        )
        content = (response.choices[0].message.content or "").strip()
    except RateLimitError as exc:
        raise HTTPException(
            status_code=402,
            detail="OpenAI quota exceeded. Check billing and limits.",
        ) from exc
    except OpenAIError as exc:
        raise HTTPException(
            status_code=502,
            detail=f"OpenAI request failed: {exc}",
        ) from exc
    data = _parse_json_or_502(content)
    return ParseResponse(**data)


def _load_record(record_id: str) -> dict:
    record_dir = RECORDS_DIR / record_id
    if not record_dir.exists():
        raise HTTPException(status_code=404, detail="Record not found.")
    result_path = record_dir / "result.json"
    audio_files = list(record_dir.glob("audio.*"))
    if not result_path.exists() or not audio_files:
        raise HTTPException(status_code=404, detail="Record data missing.")
    return {
        "id": record_id,
        "created_at": record_id.split("-")[0],
        "audio_path": audio_files[0],
        "result": json.loads(result_path.read_text(encoding="utf-8")),
    }


@app.post("/parse", response_model=ParseResponse)
def parse_trade_endpoint(payload: ParseRequest) -> ParseResponse:
    return _openai_parse(payload.text)


@app.get("/")
def index() -> FileResponse:
    return FileResponse(str(STATIC_DIR / "index.html"))


@app.post("/process", response_model=ProcessResponse)
async def process_endpoint(audio: UploadFile = File(...)) -> ProcessResponse:
    if not audio.content_type or not audio.content_type.startswith("audio/"):
        raise HTTPException(status_code=400, detail="Upload an audio file.")
    audio_bytes = await audio.read()
    result = _openai_parse_audio(audio_bytes, audio.filename or "audio.wav")
    coerced_bytes, audio_format = _coerce_audio(audio_bytes, audio.filename or "audio.wav")
    record_id = _save_record(coerced_bytes, audio_format, result)
    return ProcessResponse(result=result, record_id=record_id)


@app.get("/records")
def list_records() -> list[dict]:
    _ensure_records_dir()
    records = []
    for record_dir in sorted(RECORDS_DIR.iterdir(), reverse=True):
        if not record_dir.is_dir():
            continue
        record_id = record_dir.name
        try:
            record = _load_record(record_id)
        except HTTPException:
            continue
        records.append(
            {
                "id": record_id,
                "created_at": record["created_at"],
                "result": record["result"],
            }
        )
    return records


@app.get("/records/{record_id}")
def get_record(record_id: str) -> dict:
    record = _load_record(record_id)
    return {
        "id": record_id,
        "created_at": record["created_at"],
        "result": record["result"],
    }


@app.get("/records/{record_id}/audio")
def get_record_audio(record_id: str) -> FileResponse:
    record = _load_record(record_id)
    return FileResponse(str(record["audio_path"]))
