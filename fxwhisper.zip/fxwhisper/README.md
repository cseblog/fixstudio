# FX Voice Trade Parser

Minimal Python parser that extracts FX trade details from a spoken instruction
converted to text.

## Run (CLI)

```bash
python app.py "This is John from Alpha Capital. Buy five million euro dollar for value next Friday."
```

## Output

```json
{
  "client": "Alpha Capital",
  "currency_pair": "EUR/USD",
  "side": "buy",
  "size": 5000000,
  "value_date": "2026-02-06",
  "confidence": "high"
}
```

## Run (API)

```bash
pip install -r requirements.txt
export OPENAI_API_KEY="your-key"
uvicorn api:app --reload
```

Open `http://127.0.0.1:8000/` for the web UI.

Note: If you record in the browser, the server converts WebM to WAV using
`ffmpeg`. Install it with `brew install ffmpeg`.

The UI also lists saved recordings and lets you replay them.

## Next.js UI (Professional GUI)

```bash
cd frontend
npm install
npm run dev
```

Set the API base if your FastAPI server is not on port 8000:

```bash
export NEXT_PUBLIC_API_BASE="http://127.0.0.1:8000"
```

### Parse text

```bash
curl -X POST http://127.0.0.1:8000/parse \
  -H "Content-Type: application/json" \
  -d '{"text":"Buy five million euro dollar for value next Friday."}'
```

### Process audio (direct audio -> JSON)

```bash
curl -X POST "http://127.0.0.1:8000/process" \
  -F "audio=@/path/to/audio.wav"
```

## Browser Web Speech API (example)

```javascript
const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.lang = "en-US";
recognition.onresult = async (event) => {
  const text = event.results[0][0].transcript;
  await fetch("http://127.0.0.1:8000/parse", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text }),
  });
};
recognition.start();
```
